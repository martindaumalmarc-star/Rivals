import { useState, useMemo, useEffect } from "react";

const rolesConfig = [
  { key: "tanque1", label: "🛡️ Tanque 1", area: "front" },
  { key: "tanque2", label: "🛡️ Tanque 2", area: "front" },
  { key: "dps1", label: "⚔️ Daño 1", area: "middle" },
  { key: "dps2", label: "⚔️ Daño 2", area: "middle" },
  { key: "support1", label: "💊 Support 1", area: "back" },
  { key: "support2", label: "💊 Support 2", area: "back" },
];

const areaColors = {
  front: "#1E40AF",
  middle: "#B91C1C",
  back: "#047857",
};

function PlayerButton({ player, setDragging, readonly }) {
  return (
    <button
      draggable={!readonly}
      onDragStart={(e) => {
        if (readonly) return;
        e.dataTransfer.setData("text/plain", player);
        setDragging(player);
      }}
      onDragEnd={() => setDragging(null)}
      className="bg-gradient-to-br from-indigo-600 to-purple-700 w-24 h-24 sm:w-32 sm:h-32 rounded-full cursor-grab shadow-lg font-extrabold text-white text-base sm:text-lg flex items-center justify-center transition-transform transform hover:scale-110 hover:shadow-2xl active:scale-95 tracking-wide"
    >
      {player}
    </button>
  );
}

function RoleSlot({ role, assigned, onDrop, onClear, dragging, readonly }) {
  const color = areaColors[role.area];
  const [isOver, setIsOver] = useState(false);
  const [flash, setFlash] = useState(false);

  const handleDrop = (e) => {
    e.preventDefault();
    if (readonly) return;
    const player = e.dataTransfer.getData("text/plain");
    if (!player) return;
    setFlash(true);
    setTimeout(() => setFlash(false), 300);
    onDrop(role.key, player);
  };

  const handleDragOver = (e) => { e.preventDefault(); setIsOver(true); };
  const handleDragLeave = () => setIsOver(false);

  const backgroundColor = assigned
    ? "rgba(30,30,30,0.6)"
    : flash
    ? `${color}AA`
    : isOver
    ? `${color}50`
    : `${color}20`;

  const boxShadow = isOver
    ? `0 0 35px ${color}, 0 0 50px ${color}55`
    : `0 0 15px ${color}`;

  return (
    <button
      data-area={role.area}
      onDragOver={handleDragOver}
      onDragLeave={handleDragLeave}
      onDrop={handleDrop}
      onDoubleClick={() => !readonly && onClear(role.key)}
      className="rounded-[2rem] w-full sm:w-80 min-h-64 sm:min-h-80 border-4 border-dashed flex items-center justify-center transition-transform duration-300 hover:scale-105 animate-pulseSlot"
      style={{
        borderColor: color,
        backgroundColor: backgroundColor,
        color: "white",
        boxShadow: boxShadow,
      }}
    >
      {assigned ? (
        <span className="px-6 py-4 rounded-full text-lg font-extrabold">{assigned}</span>
      ) : (
        <span className="text-white/5 text-lg select-none">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>
      )}
    </button>
  );
}

export default function App() {
  const [players] = useState(["Martinator","Danielmstrong","Sackontorn","Catsuriken","Pin"]);
  const [assigned, setAssigned] = useState({});
  const [dragging, setDragging] = useState(null);

  const params = new URLSearchParams(window.location.search);
  const readonly = params.get("readonly") === "true";

  useEffect(() => {
    const newAssigned = {};
    rolesConfig.forEach(role => {
      const value = params.get(role.key);
      if (value) newAssigned[role.key] = value;
    });
    if (Object.keys(newAssigned).length > 0) setAssigned(newAssigned);
  }, []);

  useEffect(() => {
    const url = new URL(window.location);
    Object.keys(assigned).forEach(key => url.searchParams.set(key, assigned[key]));
    if(readonly) url.searchParams.set("readonly","true");
    window.history.replaceState(null, "", url);
  }, [assigned, readonly]);

  const handleDrop = (roleKey, player) => setAssigned(prev => ({ ...prev, [roleKey]: player }));
  const handleClear = (roleKey) => { const newAssigned = { ...assigned }; delete newAssigned[roleKey]; setAssigned(newAssigned); };
  const handleResetAll = () => setAssigned({});

  const rolesByArea = useMemo(() => {
    return rolesConfig.reduce((acc, role) => {
      acc[role.area] = acc[role.area] || [];
      acc[role.area].push(role);
      return acc;
    }, {});
  }, []);

  const renderArea = (area, title) => (
    <div className="space-y-4">
      <h2 className="text-center font-bold text-lg text-gray-300 tracking-wide">{title}</h2>
      <div className="flex flex-col sm:grid sm:grid-cols-2 gap-6 sm:gap-8 justify-center items-center">
        {rolesByArea[area].map(role => (
          <RoleSlot key={role.key} role={role} assigned={assigned[role.key]} onDrop={handleDrop} onClear={handleClear} dragging={dragging} readonly={readonly} />
        ))}
      </div>
    </div>
  );

  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-br from-gray-900 via-gray-800 to-black text-white p-4 sm:p-6 font-sans">
      <h1 className="text-4xl sm:text-6xl font-extrabold text-center mb-6 sm:mb-8 tracking-wider text-transparent bg-clip-text bg-gradient-to-r from-indigo-400 via-purple-500 to-pink-500 animate-pulseGlow">🎮 Un Rivals</h1>
      <div className="flex flex-col sm:flex-row justify-center gap-4 sm:gap-6 mb-8 sm:mb-12 items-center">
        {players.map(player => <PlayerButton key={player} player={player} setDragging={setDragging} readonly={readonly} />)}
      </div>
      <div className="flex-1 max-w-6xl mx-auto space-y-8 sm:space-y-12">
        {renderArea("front","⬆️ Línea frontal (Tanques)")}
        {renderArea("middle","⚔️ Línea media (Daño)")}
        {renderArea("back","⬇️ Línea trasera (Support)")}
      </div>
      <div className="flex justify-center mt-8 sm:mt-12">
        {!readonly && <button onClick={handleResetAll} className="bg-red-600 hover:bg-red-700 text-white font-bold px-8 py-4 rounded-3xl shadow-xl transition transform hover:scale-110 fixed bottom-8">🗑️ A tomar por saco el equipo</button>}
      </div>
      <style>{`
        @keyframes pulseGlow { 0% { text-shadow: 0 0 10px #8b5cf6,0 0 20px #8b5cf6;} 50% { text-shadow: 0 0 20px #ec4899,0 0 40px #ec4899;} 100% { text-shadow: 0 0 10px #8b5cf6,0 0 20px #8b5cf6;}}
        .animate-pulseGlow { animation: pulseGlow 2.5s infinite;}
        @keyframes pulseSlot { 0% { box-shadow: 0 0 10px #fff5;} 50% { box-shadow: 0 0 25px #fff8;} 100% { box-shadow: 0 0 10px #fff5;}}
        .animate-pulseSlot { animation: pulseSlot 2s infinite;}
      `}</style>
    </div>
  );
}